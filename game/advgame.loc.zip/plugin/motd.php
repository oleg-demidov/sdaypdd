<html>
<head>
<script type="text/javascript">
window.onload = function(){
    var popup=window.open("<? echo $_GET['href'];?>","Test Page :D","height=800,width=1000");
};
</script>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"></head>
<body>
</body>
</html>