
<table align="center"  border="0">
  <tr>
    <td><? echo content('continue_pay_admin',$content_buy);?> <b><? echo $dataForm['email'];?></b>
	</td>
  </tr>
</table>
