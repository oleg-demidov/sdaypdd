<form class="sup_que" action="<? echo $host.$_SERVER['REQUEST_URI'];?>" method="post">
<table>
<tr>
<tr><td><input type="text" style="visibility:hidden;" name="id_post" value="<? echo $id_post?>">
<textarea style="width:450px;" name="text" class="text_pole" rows="2"></textarea></td>
<td><input style="margin:0 0 0 50px;" type="submit" class="button"></td></tr>
</table>
</form>