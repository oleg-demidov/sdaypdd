<div class="menu2">
<? include('../elements/menu2index.php');?>
<a href="<? echo $host_lang;?>/advertiser/index.php?a=stat"><? echo content('stat')?></a>
<a href="<? echo $host_lang;?>/advertiser/index.php?a=company"><? echo content('campaign',$content_adv)?></a>
<a href="<? echo $host_lang;?>/advertiser/index.php?a=support"><? echo content('support')?></a>
<a style="color:#6FE6FF;" href="<? echo $host_lang;?>/advertiser/index.php?a=faq&c=faq_adv"><? echo content('faq')?></a>
</div>
