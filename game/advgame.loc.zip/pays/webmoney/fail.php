<? 
header("Location: http://cs-money.net/pays/index.php?a=fail&id=".$_POST['LMI_PAYMENT_NO']);
?>


