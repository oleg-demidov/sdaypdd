<div class="footer">
<!-- begin WebMoney Transfer : attestation label -->
<div><a href="https://passport.webmoney.ru/asp/certview.asp?wmid=135986091152" target="_blank"><img src="http://www.megastock.ru/doc/Logo/v_blue_on_white_ru.png" alt="Здесь находится аттестат нашего WM идентификатора 135986091152" border="0" /><br /><span style="font-size: 0,7em;"><? echo content('check_pt')?></span></a></div>
<!-- end WebMoney Transfer : attestation label -->
<!-- begin WebMoney Transfer : accept label -->
<div><a href="http://www.megastock.ru/" target="_blank"><img src="http://www.megastock.ru/doc/Logo/acc_blue_on_white_ru.png" alt="www.megastock.ru" border="0"/></a>
<br><a href="<? echo $host_lang;?>/wmhow_to_pay.php"><? echo content('how_pay')?></a></div>
<!-- end WebMoney Transfer : accept label -->
<div><a  href="#"><img src="<? echo $host;?>/images/demo.png"/></a></div></div>