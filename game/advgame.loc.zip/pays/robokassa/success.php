﻿<? 
header("Location: http://cs-money.net/pays/index.php?a=success&id=".$_REQUEST["InvId"]);
?>


