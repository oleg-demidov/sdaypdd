<?
function include_social_data($data){
	if(!isset($_SESSION['id']))
		return false;
	
}
?>