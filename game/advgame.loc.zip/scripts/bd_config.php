<?
$user_bd="a111564_csmoney";
$pass_bd="xTekhIl6wP";
$host_bd="a111564.mysql.mchost.ru";
$bd_cs="shows_tables";
$bd_custom="a111564_1";
?>