<?
$key="skjrhgswertg654g35h4654strhsw5h";
?>