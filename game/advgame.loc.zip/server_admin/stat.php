<h3 style="margin:5px;"><? echo content('stat_servers',$content_sa); ?></h3>

<?
include('../elements/adm_stat_servers.php');
include('../elements/adm_stat_table.php');
include('../elements/balans_table.php');
include('../elements/form_stat_adm.php');
include('../elements/gcharts.php');
?>

