﻿<?
//phpinfo();
//echo 'string2 '.pack("S",2222);
//file_put_contents ( 'put.fl' , pack("S",2222), FILE_BINARY  );
echo date('Y,m,d',1393783200);
?>