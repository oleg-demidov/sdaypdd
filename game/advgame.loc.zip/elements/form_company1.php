	<form enctype="multipart/form-data" action="<?php echo 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];?>&step=1" method="post">
	 <h3>Загрузить баннер</h3>
    	<table cellpadding="10" cellspacing="0" border="0" class="table_form" >
    <tr>
		<td><input type="file" name="sprite"></td><td>Загрузите файл баннера - <b>только gif</b></td>
	</tr>
	<tr>
	<td><input name="" class="button" type="submit" value="Далее"></td>
	<td></td>
</tr> </table>
    </form>

