<? 
header("Location: http://cs-money.net/pays/index.php?a=fail&id=".$_REQUEST["InvId"]);
?>


