<div class="logo">
<!--<div class="solders">
</div>-->
<script type="text/javascript" src="../slider/coin-slider.min.js"></script>
<link rel="stylesheet" href="../slider/coin-slider-styles.css" type="text/css" />
<div class="slider">
<div id='coin-slider'>
	<a href="#"><img src='../slider/images/slide1.jpg' >
	<span>Баннеры на стенах</span>
	</a><a href="#"><img src='../slider/images/slide2.jpg' >
	<span>Баннеры на стенах</span>
	</a><a href="#"><img src='../slider/images/slide3.jpg' >
	<span>Баннеры на стенах</span>
	</a><a href="#"><img src='../slider/images/slide4.jpg' >
	<span>Баннеры на стенах</span>
	</a><a href="#"><img src='../slider/images/slide5.jpg' >
	<span>Баннеры на стенах</span>
	</a><a href="#"><img src='../slider/images/slide6.jpg' >
	<span>Переходы по ссылке</span>
	</a>
	
</div>
</div>
<script type="text/javascript">
	$(document).ready(function() {
		$('#coin-slider').coinslider({ width: 980,height: 500, delay: 10000 });
	});
</script>



</div>