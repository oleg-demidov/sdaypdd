﻿<?
//phpinfo();
echo'do1';
	include('convert_spr.php');
	$f=new Image2Sprite('sprite.spr',array('262670.png'),VP_PARALLEL,SPR_NORMAL);
	echo'do';
?>